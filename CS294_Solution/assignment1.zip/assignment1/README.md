Details about this assignment can be found [on the course webpage](https://bcourses.berkeley.edu/courses/1453965/assignments/7738616)
